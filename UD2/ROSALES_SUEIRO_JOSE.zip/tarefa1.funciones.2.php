<?php

// 2. Crea una función que reciba un string e devolva a súa lonxitude.

function longitud($string){
    return strlen($string);
}

?>