<?php
//Tarea 1 de la UD2 DWES empieza el 06/10/2023


/*
Localiza y corrige los errores de este programa PHP:
```php

<? php
echo '¿Cómo estás';
echo 'Estoy bien, gracias.';
??>
```
**/

/*Respuesta: En la línea 9 no se puede dejar el espacio ente <? php sino que debe ser <?php
            En la línea 12 para cerrar el código debemos poner ?> en lugar de ??>

 El código quedaría: */

echo '¿Cómo estás';
echo 'Estoy bien, gracias.';
?>
 
