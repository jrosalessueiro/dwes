<?php

/* 2. Imprime los valores del array asociativo siguiente usando un foreach:*/
$v[1]=90;
$v[10] = 200;
$v['hola']=43;
$v[9]='e';

foreach ($v as $valor) {
    echo $valor . "\n";
}
?>