<?php
/*4. Hacer un programa php que calcule el área y el perímetro de un rectángulo
 (```área=base*altura``` y (```perímetro=2*base+2*altura```). Debéis declarar 
 las variables base=20 y altura=10. */

 $base = 20;
 $altura = 10;

 $area = $base * $altura;
 $perimetro = 2 * $base + 2 * $altura;

 echo "El área del rectángulo es: " . $area . "\n";
 echo "El perímetro del rectángulo es: " . $perimetro . "\n";


 ?>